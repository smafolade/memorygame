export const cardData = [
{
    "id": 1,
    "url": "/assets/cards/card-spades-1.png"
},
{
    "id": 2,
    "url": "/assets/cards/card-spades-2.png"
},
{
    "id": 3,
    "url": "/assets/cards/card-spades-3.png"
},
{
    "id": 4,
    "url": "/assets/cards/card-spades-4.png"
},
{
    "id": 5,
    "url": "/assets/cards/card-spades-5.png"
},
{
    "id": 6,
    "url": "/assets/cards/card-spades-6.png"
},
{
    "id": 7,
    "url": "/assets/cards/card-spades-7.png"
},
{
    "id": 8,
    "url": "/assets/cards/card-spades-8.png"
},
{
    "id": 9,
    "url": "/assets/cards/card-spades-9.png"
},
{
    "id": 10,
    "url": "/assets/cards/card-spades-10.png"
},
{
    "id": 11,
    "url": "/assets/cards/card-spades-11.png"
},
{
    "id": 12,
    "url": "/assets/cards/card-spades-12.png"
},
{
    "id": 13,
    "url": "/assets/cards/card-spades-13.png"
},
{
    "id": 14,
    "url": "/assets/cards/card-clubs-1.png"
},
{
    "id": 15,
    "url": "/assets/cards/card-clubs-2.png"
},
{
    "id": 16,
    "url": "/assets/cards/card-clubs-3.png"
},
{
    "id": 17,
    "url": "/assets/cards/card-clubs-4.png"
},
{
    "id": 18,
    "url": "/assets/cards/card-clubs-5.png"
},
{
    "id": 19,
    "url": "/assets/cards/card-clubs-6.png"
},
{
    "id": 20,
    "url": "/assets/cards/card-clubs-7.png"
},
{
    "id": 21,
    "url": "/assets/cards/card-clubs-8.png"
},
{
    "id": 22,
    "url": "/assets/cards/card-clubs-9.png"
},
{
    "id": 23,
    "url": "/assets/cards/card-clubs-10.png"
},
{
    "id": 24,
    "url": "/assets/cards/card-clubs-11.png"
},
{
    "id": 25,
    "url": "/assets/cards/card-clubs-12.png"
},
{
    "id": 26,
    "url": "/assets/cards/card-clubs-13.png"
},
{
    "id": 27,
    "url": "/assets/cards/card-diamonds-1.png"
},
{
    "id": 28,
    "url": "/assets/cards/card-diamonds-2.png"
},
{
    "id": 29,
    "url": "/assets/cards/card-diamonds-3.png"
},
{
    "id": 30,
    "url": "/assets/cards/card-diamonds-4.png"
},
{
    "id": 31,
    "url": "/assets/cards/card-diamonds-5.png"
},
{
    "id": 32,
    "url": "/assets/cards/card-diamonds-6.png"
},
{
    "id": 33,
    "url": "/assets/cards/card-diamonds-7.png"
},
{
    "id": 34,
    "url": "/assets/cards/card-diamonds-8.png"
},
{
    "id": 35,
    "url": "/assets/cards/card-diamonds-9.png"
},
{
    "id": 36,
    "url": "/assets/cards/card-diamonds-10.png"
},
{
    "id": 37,
    "url": "/assets/cards/card-diamonds-11.png"
},
{
    "id": 38,
    "url": "/assets/cards/card-diamonds-12.png"
},
{
    "id": 39,
    "url": "/assets/cards/card-diamonds-13.png"
},
{
    "id": 40,
    "url": "/assets/cards/card-hearts-1.png"
},
{
    "id": 41,
    "url": "/assets/cards/card-hearts-2.png"
},
{
    "id": 42,
    "url": "/assets/cards/card-hearts-3.png"
},
{
    "id": 43,
    "url": "/assets/cards/card-hearts-4.png"
},
{
    "id": 44,
    "url": "/assets/cards/card-hearts-5.png"
},
{
    "id": 45,
    "url": "/assets/cards/card-hearts-6.png"
},
{
    "id": 46,
    "url": "/assets/cards/card-hearts-7.png"
},
{
    "id": 47,
    "url": "/assets/cards/card-hearts-8.png"
},
{
    "id": 48,
    "url": "/assets/cards/card-hearts-9.png"
},
{
    "id": 49,
    "url": "/assets/cards/card-hearts-10.png"
},
{
    "id": 50,
    "url": "/assets/cards/card-hearts-11.png"
},
{
    "id": 51,
    "url": "/assets/cards/card-hearts-12.png"
},
{
    "id": 52,
    "url": "/assets/cards/card-hearts-13.png"
}
]